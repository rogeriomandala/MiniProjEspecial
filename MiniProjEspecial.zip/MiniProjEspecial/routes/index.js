var express = require('express');
var router = express.Router();
var db = require('../server/db_euromilhoes');
//registar apostas
router.post('/api/aposta', db.inseriraposta);
//listarApostas
router.get('/api/aposta', db.listarApostas);
// verificar se esta repetida 
router.put('/api/aposta-repetida', db.verificarRepeticao);
//validar chave
router.put('/api/validar-chave', db.validarChave);
//gerar chave
//validar chaves
//notificar numero de vezes
//listar/historico das apostas

//teste de rotas com mongodb
//router.get('/api/mongo', mongo.getMongoTeste);
//router.get('/api/postdata', mongo.postData);
//router.get('/api/chaves', db.getChaves);
//postData  

module.exports = router;